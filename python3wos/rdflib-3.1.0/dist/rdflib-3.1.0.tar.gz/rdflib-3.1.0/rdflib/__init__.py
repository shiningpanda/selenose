#-*- coding: utf-8 -*-
class Graph(object):
    def parse(*args, **kwargs):
        raise NotImplementedError('this is a mock of rdflib... waiting their Python 3 support!')